<?php
session_start();

function requireLogin() {
    if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
        header("Location: login.php");
        exit;
    }
}

function requireRole($role) {
    if (!isset($_SESSION['ruolo']) || $_SESSION['ruolo'] !== $role) {
        http_response_code(403);
        die("Accesso non autorizzato. Richiesto ruolo: $role");
    }
}

function isLoggedIn() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'];
}

function getUserRole() {
    return $_SESSION['ruolo'] ?? null;
}
