<footer>
    <p>&copy; <?php echo date('Y'); ?> BiblioTech. Tutti i diritti riservati.</p>
    <p><a href="registrazione.php" class="btn-register-footer">Registrati</a></p>
</footer>
