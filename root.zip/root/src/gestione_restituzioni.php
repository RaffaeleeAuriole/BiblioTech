<?php
require 'config.php';
require 'auth.php';
requireLogin();
requireRole('bibliotecario');

$prestiti = $pdo->query("SELECT p.*, u.email, l.titolo FROM prestiti p 
JOIN utenti u ON p.utente_id=u.id 
JOIN libri l ON p.libro_id=l.id")->fetchAll();

include 'header.php';
?>
<h3>Gestione Restituzioni</h3>
<div class="cards">
<?php foreach($prestiti as $p): ?>
<div class="card">
<h4><?= htmlspecialchars($p['titolo']) ?></h4>
<p>Studente: <?= htmlspecialchars($p['email']) ?></p>
<p>Data prestito: <?= $p['data_prestito'] ?></p>
<a href="restituisci.php?id=<?= $p['id'] ?>" class="btn btn-danger">Segna come Restituito</a>
</div>
<?php endforeach; ?>
</div>
