<?php
if(session_status() === PHP_SESSION_NONE) session_start();
?>
<header>
    <div class="logo"><h1>BiblioTech</h1></div>
    <nav>
        <a href="home.php">Home</a>
        <a href="libri.php">Libri</a>
        <a href="prestiti.php">Prestiti</a>
        <?php if(isset($_SESSION['user_id'])): ?>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="registrazione.php">Registrati</a>
        <?php endif; ?>
    </nav>
</header>
