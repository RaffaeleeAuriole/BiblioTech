<?php
session_start();
require_once 'config.php';

// Controllo se l'utente è loggato
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

// Preleva tutti i libri dal database
$sql = "SELECT * FROM libri";
$result = $conn->query($sql);
?>

<?php include 'header.php'; ?>
<link rel="stylesheet" href="assets/style.css">

<div class="page-container">
    <h1>Catalogo Libri</h1>
    <p>Qui puoi vedere tutti i libri disponibili nella biblioteca.</p>

    <?php if($result->num_rows > 0): ?>
        <table class="libri-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Titolo</th>
                    <th>Autore</th>
                    <th>Copie Totali</th>
                    <th>Copie Disponibili</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><a href="libro.php?id=<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['titolo']); ?></a></td>
                        <td><?php echo htmlspecialchars($row['autore']); ?></td>
                        <td><?php echo $row['copie_totali']; ?></td>
                        <td><?php echo $row['copie_disponibili']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nessun libro presente.</p>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>
