<?php
require 'config.php';
require 'auth.php';
requireLogin();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM libri WHERE id=?");
$stmt->execute([$id]);
$libro = $stmt->fetch();

include 'header.php';
?>
<?php if($libro): ?>
<div class="card">
<h3><?= htmlspecialchars($libro['titolo']) ?></h3>
<p>Autore: <?= htmlspecialchars($libro['autore']) ?></p>
<p>ISBN: <?= htmlspecialchars($libro['isbn']) ?></p>
<p>Disponibili: <?= $libro['quantita'] ?></p>
<a href="prestiti.php?id=<?= $libro['id'] ?>" class="btn btn-primary">Richiedi Prestito</a>
</div>
<?php else: ?>
<p>Libro non trovato.</p>
<?php endif; ?>
