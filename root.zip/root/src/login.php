<?php
session_start();
require_once "config.php";

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $totp_code = $_POST['totp'] ?? null;

    $stmt = $conn->prepare("SELECT * FROM utenti WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($user = $result->fetch_assoc()) {
        if (password_verify($password, $user['password'])) {
            // Verifica TOTP se fornito
            if ($totp_code) {
                require 'vendor/autoload.php';
                $totp = new \OTPHP\TOTP($user['totp_secret']);
                if (!$totp->verify($totp_code)) {
                    $error = "Codice TOTP non valido.";
                }
            }
            if(!$error){
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['ruolo'] = $user['ruolo'];
                header("Location: home.php");
                exit;
            }
        } else {
            $error = "Password errata.";
        }
    } else {
        $error = "Email non registrata.";
    }
}
?>

<?php include 'header.php'; ?>
<link rel="stylesheet" href="assets/style.css">

<form method="POST" action="login.php">
    <h2>Login</h2>
    <?php if($error) echo "<p class='error-msg'>$error</p>"; ?>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="text" name="totp" placeholder="TOTP (se attivo)">
    <button type="submit">Accedi</button>
    <p><a href="reset_pw.php">Password dimenticata?</a></p>
</form>

<?php include 'footer.php'; ?>
