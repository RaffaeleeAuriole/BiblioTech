<?php
require 'config.php';
require 'auth.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$prestiti = $pdo->prepare("SELECT p.*, l.titolo FROM prestiti p JOIN libri l ON p.libro_id = l.id WHERE p.utente_id=?");
$prestiti->execute([$user_id]);
$prestiti = $prestiti->fetchAll();

include 'header.php';
?>
<h3>I miei Prestiti</h3>
<div class="cards">
<?php foreach($prestiti as $p): ?>
<div class="card">
<h4><?= htmlspecialchars($p['titolo']) ?></h4>
<p>Data prestito: <?= $p['data_prestito'] ?></p>
<p>Scadenza: <?= $p['data_restituzione'] ?></p>
<a href="restituisci.php?id=<?= $p['id'] ?>" class="btn btn-danger">Restituisci</a>
</div>
<?php endforeach; ?>
</div>
