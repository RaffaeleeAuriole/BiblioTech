<?php
require_once "auth.php";
requireRole("studente");

$id_libro = $_GET["id"];

try {
    $pdo->beginTransaction();

    // Controllo copie disponibili
    $stmt = $pdo->prepare("SELECT copie_disponibili FROM libri WHERE id = ? FOR UPDATE");
    $stmt->execute([$id_libro]);
    $libro = $stmt->fetch();

    if ($libro["copie_disponibili"] <= 0) {
        throw new Exception("Libro non disponibile.");
    }

    // Inserisco prestito
    $stmt = $pdo->prepare("INSERT INTO prestiti (id_utente, id_libro) VALUES (?, ?)");
    $stmt->execute([$_SESSION["utente_id"], $id_libro]);

    // Aggiorno copie
    $stmt = $pdo->prepare("UPDATE libri SET copie_disponibili = copie_disponibili - 1 WHERE id = ?");
    $stmt->execute([$id_libro]);

    $pdo->commit();
    header("Location: prestiti.php");
    exit;

} catch (Exception $e) {
    $pdo->rollBack();
    die("Errore nel prestito: " . $e->getMessage());
}
