<?php

$messaggio = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];

    // Cerco l'utente
    $stmt = $pdo->prepare("SELECT id FROM utenti WHERE email = ?");
    $stmt->execute([$email]);
    $utente = $stmt->fetch();

    if ($utente) {
        // Genero token casuale
        $token = bin2hex(random_bytes(32));
        $token_hash = hash("sha256", $token);

        // Scadenza: 30 minuti
        $scadenza = date("Y-m-d H:i:s", time() + 1800);

        // Salvo il token hash nel database
        $stmt = $pdo->prepare("
            INSERT INTO password_reset_tokens (id_utente, token_hash, expires_at)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$utente["id"], $token_hash, $scadenza]);

        // In un progetto reale: invio email con il link
        // Qui lo mostriamo a schermo per sviluppo/test
        $link = "http://localhost/reset_pw.php?token=" . $token;

        $messaggio = "Link di reset (solo per sviluppo): <br><a href='$link'>$link</a>";
    } else {
        // Messaggio generico per non rivelare se l'email esiste
        $messaggio = "Se l'email esiste, riceverai un link di reset.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="assets/style.css">
  <title>Password dimenticata</title>
</head>
<body>
<div class="container">
  <div class="card">
    <h2>Recupero password</h2>

    <?php if ($messaggio): ?>
      <div class="alert alert-success"><?= $messaggio ?></div>
    <?php endif; ?>

    <form method="POST">
      <label>Email</label>
      <input type="email" name="email" required>
      <button>Invia link di reset</button>
    </form>

    <a href="login.php">Torna al login</a>
  </div>
</div>
</body>
</html>
