<?php
session_start();
require_once "config.php";

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    if($password !== $password_confirm){
        $error = "Le password non coincidono.";
    } else {
        $totp_secret = bin2hex(random_bytes(10)); // generazione semplice TOTP
        $hash = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $conn->prepare("INSERT INTO utenti (email, password, ruolo, totp_secret) VALUES (?, ?, 'studente', ?)");
        $stmt->bind_param("sss", $email, $hash, $totp_secret);

        if($stmt->execute()){
            $success = "Registrazione completata! Puoi fare login ora.";
        } else {
            $error = "Errore nella registrazione. Email già esistente?";
        }
    }
}
?>

<?php include 'header.php'; ?>
<link rel="stylesheet" href="assets/style.css">

<form method="POST" action="registrazione.php">
    <h2>Registrazione</h2>
    <?php if($error) echo "<p class='error-msg'>$error</p>"; ?>
    <?php if($success) echo "<p class='success-msg'>$success</p>"; ?>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="password" name="password_confirm" placeholder="Conferma Password" required>
    <button type="submit">Registrati</button>
</form>

<?php include 'footer.php'; ?>
