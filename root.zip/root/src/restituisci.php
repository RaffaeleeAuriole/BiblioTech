<?php
require 'config.php';
require 'auth.php';
requireLogin();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("DELETE FROM prestiti WHERE id=? AND utente_id=?");
$stmt->execute([$id,$_SESSION['user_id']]);
header("Location: prestiti.php");
exit;
